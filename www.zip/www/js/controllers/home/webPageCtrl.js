angular.module('app.controllers')
  .controller('WebPageCtrl', function($scope, $stateParams) {
    var vm = $scope.vm = {};
    vm.pageUrl="/ele";
  })
