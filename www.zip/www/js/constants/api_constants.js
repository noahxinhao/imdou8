angular.module('app.constants').constant('serveApi', {
  "ACCOUNT": {
    "USER_LOGIN_URL": "rest/user/login",
    "USER_SIGN_URL": "rest/user/signUp"
  }
});
